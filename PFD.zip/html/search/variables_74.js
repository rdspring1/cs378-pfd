var searchData=
[
  ['task_5fleft',['task_left',['../SpherePFD_8c_09_09.html#a38c1d599161c0222c30c3040d12988c9',1,'SpherePFD.c++']]],
  ['total_5fvertices',['total_vertices',['../classtest.html#ade6a54d6ab560bb6d6183052131ef064',1,'test']]]
];
