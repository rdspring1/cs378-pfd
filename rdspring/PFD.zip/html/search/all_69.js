var searchData=
[
  ['initial_5fvalue',['INITIAL_VALUE',['../PFD_8h.html#a54f1d320a82c516bd90957baa4163a4c',1,'INITIAL_VALUE():&#160;PFD.h'],['../SpherePFD_8c_09_09.html#a54f1d320a82c516bd90957baa4163a4c',1,'INITIAL_VALUE():&#160;SpherePFD.c++']]]
];
