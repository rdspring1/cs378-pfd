var searchData=
[
  ['max_5fsize',['MAX_SIZE',['../PFD_8h.html#a0592dba56693fad79136250c11e5a7fe',1,'MAX_SIZE():&#160;PFD.h'],['../SpherePFD_8c_09_09.html#a0592dba56693fad79136250c11e5a7fe',1,'MAX_SIZE():&#160;SpherePFD.c++']]]
];
