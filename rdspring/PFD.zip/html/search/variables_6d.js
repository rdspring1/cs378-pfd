var searchData=
[
  ['min_5fheap',['min_heap',['../SpherePFD_8c_09_09.html#a2baa6214040c6b9867cc70af8c8dc40c',1,'SpherePFD.c++']]]
];
