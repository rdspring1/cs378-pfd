var searchData=
[
  ['initial_5ftotal_5ftask',['initial_total_task',['../SpherePFD_8c_09_09.html#a4bb039d4d6923c8e710b48c50aaac81a',1,'SpherePFD.c++']]],
  ['initial_5fvalue',['initial_value',['../SpherePFD_8c_09_09.html#a5a798d35e11a8dc4792deff2372ee122',1,'SpherePFD.c++']]]
];
